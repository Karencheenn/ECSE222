library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

--use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity Karen_Chen_rca_behavioral is
	port(
		A, B: in std_logic_vector (3 downto 0);
		S: 	out std_logic_vector (4 downto 0)
	);
end Karen_Chen_rca_behavioral;

architecture rca_behave of Karen_Chen_rca_behavioral is

	--signal S_temp: std_logic_vector (4 downto 0);
begin
	S<= '0' & A + B;
end;