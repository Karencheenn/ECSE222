transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {P:/ECSE 222/VHDL4_Karen_Chen_Lai/VHDL4/Karen_Chen_comparator.vhd}

vcom -93 -work work {P:/ECSE 222/VHDL4_Karen_Chen_Lai/VHDL4/Karen_Chen_comparator_tb.vhd}

vsim -t 1ps -L altera -L lpm -L sgate -L altera_mf -L altera_lnsim -L cyclonev -L rtl_work -L work -voptargs="+acc"  tb

add wave *
view structure
view signals
run -all
